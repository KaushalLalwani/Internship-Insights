#analyzer.py
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def analyze_internship_data(file_path='data/internshala_cleaned_jobs.csv'):
    
    try:
        df = pd.read_csv(file_path)
        print(f"DataFrame loaded successfully from '{file_path}'.")
    except FileNotFoundError:
        print(f"Error: '{file_path}' not found. Please ensure the data cleaning script has run successfully.")
        return

    print("\n--- Initial Data Overview ---")
    print("DataFrame Head:")
    print(df.head())
    print("\nDataFrame Info:")
    print(df.info())
    print("\nDataFrame Description (Numerical Columns):")
    print(df.describe())
    print("\nMissing Values:")
    print(df.isnull().sum())

    # --- EDA Summaries ---
    print("\n--- Exploratory Data Analysis (EDA) ---")

    # 1. Distribution of Average Stipend
    print("\nDistribution of Average Stipend:")
    plt.figure(figsize=(10, 6))
    sns.histplot(df['Average Stipend'].dropna(), bins=20, kde=True)
    plt.title('Distribution of Average Stipend')
    plt.xlabel('Average Stipend (INR)')
    plt.ylabel('Number of Internships')
    plt.grid(axis='y', alpha=0.75)
    plt.show()

    # 2. Top Locations
    print("\nTop 10 Locations for Internships:")
    top_locations = df['Location'].value_counts().head(10)
    print(top_locations)
    plt.figure(figsize=(12, 7))
    sns.barplot(x=top_locations.values, y=top_locations.index, palette='viridis')
    plt.title('Top 10 Internship Locations')
    plt.xlabel('Number of Internships')
    plt.ylabel('Location')
    plt.show()

    # 3. Distribution of Duration
    print("\nDistribution of Internship Duration (Months):")
    plt.figure(figsize=(8, 5))
    sns.countplot(x=df['Duration (Months)'].dropna(), palette='coolwarm')
    plt.title('Distribution of Internship Duration')
    plt.xlabel('Duration (Months)')
    plt.ylabel('Number of Internships')
    plt.show()

    # 4. Stipend vs. Duration
    print("\nAverage Stipend by Duration (Months):")
    stipend_by_duration = df.groupby('Duration (Months)')['Average Stipend'].mean().sort_values(ascending=False)
    print(stipend_by_duration)
    plt.figure(figsize=(10, 6))
    sns.barplot(x=stipend_by_duration.index, y=stipend_by_duration.values, palette='magma')
    plt.title('Average Stipend by Internship Duration')
    plt.xlabel('Duration (Months)')
    plt.ylabel('Average Stipend (INR)')
    plt.show()

    # 5. Mode of Internship Distribution
    print("\nDistribution of Internship Mode:")
    mode_counts = df['Mode'].value_counts()
    print(mode_counts)
    plt.figure(figsize=(7, 7))
    plt.pie(mode_counts, labels=mode_counts.index, autopct='%1.1f%%', startangle=90, colors=sns.color_palette('pastel'))
    plt.title('Distribution of Internship Mode')
    plt.axis('equal') 
    plt.show()


    print("\n--- Feature Extraction Examples ---")

  
    df['Job Role Category'] = df['Job Title'].apply(lambda x: x.split(' ')[0] if pd.notna(x) else 'N/A')
    print("\nAdded 'Job Role Category' feature. Head:")
    print(df[['Job Title', 'Job Role Category']].head())


    df['Is Actively Hiring'] = df['Company'].apply(lambda x: 1 if 'Trading Fox' in str(x) else 0)
    print("\nAdded 'Is Actively Hiring' feature (placeholder). Head:")
    print(df[['Company', 'Is Actively Hiring']].head())

    # Example 3: Creating 'Stipend Per Month Category'
    bins = [0, 5000, 10000, 15000, 20000, np.inf]
    labels = ['<5K', '5K-10K', '10K-15K', '15K-20K', '>20K']
    df['Stipend Category'] = pd.cut(df['Average Stipend'], bins=bins, labels=labels, right=False, include_lowest=True)
    print("\nAdded 'Stipend Category' feature. Head:")
    print(df[['Average Stipend', 'Stipend Category']].head())

    print("\n--- Analysis Complete ---")
    print("Final DataFrame with new features (head):")
    print(df.head())
    print("\nFinal DataFrame Info (with new features):")
    print(df.info())

    

if __name__ == "__main__":
    analyze_internship_data()
