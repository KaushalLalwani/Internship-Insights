import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Set Streamlit page configuration
st.set_page_config(
    page_title="Internship Data Dashboard",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)


@st.cache_data # Cache data to avoid reloading on every rerun


def load_data(file_path='D:/Internship Insights/data/internshala_cleaned_jobs.csv'): # Using forward slashes for cross-platform compatibility
    """
    Loads the cleaned internship data from a CSV file.
    """
    try:
        df = pd.read_csv(file_path)
        numerical_cols = ['Min Stipend', 'Max Stipend', 'Average Stipend', 'Duration (Months)', 'Posted (Days Ago)']
        for col in numerical_cols:
            if col in df.columns: 
                df[col] = pd.to_numeric(df[col], errors='coerce')
        return df
    except FileNotFoundError:
        st.error(f"Error: '{file_path}' not found. Please ensure the data cleaning script has run successfully and the CSV file is located at the specified absolute path.")
        return pd.DataFrame() 
    except Exception as e:
        st.error(f"An error occurred while loading data: {e}")
        return pd.DataFrame()

# --- Load the data ---
df = load_data()



if df.empty:
    st.warning("The dashboard cannot load data. Please check the file path and ensure the CSV file is correctly generated.")
    st.stop()

# --- Dashboard Title and Introduction ---
st.title("📊 Internship Data Dashboard")
st.markdown("""
Welcome to the Internship Data Dashboard! This interactive tool allows you to explore insights
from the scraped and cleaned internship listings from Internshala.
""")

st.markdown("---")

# --- Sidebar Filters ---
st.sidebar.header("Filter Options")

# Location Filter

if 'Location' in df.columns:
    all_locations = ['All'] + sorted(df['Location'].dropna().unique().tolist())
    selected_location = st.sidebar.selectbox("Select Location", all_locations)
else:
    st.sidebar.info("Location column not found in data.")
    selected_location = 'All'

# Stipend Range Filter

if 'Average Stipend' in df.columns and not df['Average Stipend'].isnull().all():
    min_stipend_val = float(df['Average Stipend'].min())
    max_stipend_val = float(df['Average Stipend'].max())
    stipend_range = st.sidebar.slider(
        "Average Stipend Range (INR)",
        min_value=min_stipend_val,
        max_value=max_stipend_val,
        value=(min_stipend_val, max_stipend_val),
        step=1000.0
    )
else:
    st.sidebar.info("Average Stipend column not found or is empty.")
    stipend_range = (0.0, 100000.0) # Default range

# Duration Filter

if 'Duration (Months)' in df.columns:
    all_durations = ['All'] + sorted(df['Duration (Months)'].dropna().unique().tolist())
    selected_duration = st.sidebar.multiselect("Select Duration (Months)", all_durations, default='All')
else:
    st.sidebar.info("Duration (Months) column not found.")
    selected_duration = ['All'] 


# Apply filters
filtered_df = df.copy()

if selected_location != 'All' and 'Location' in filtered_df.columns:
    filtered_df = filtered_df[filtered_df['Location'] == selected_location]

if 'All' not in selected_duration and 'Duration (Months)' in filtered_df.columns:
    filtered_df = filtered_df[filtered_df['Duration (Months)'].isin(selected_duration)]


if 'Average Stipend' in filtered_df.columns and not filtered_df['Average Stipend'].isnull().all():
    filtered_df = filtered_df[
        (filtered_df['Average Stipend'] >= stipend_range[0]) &
        (filtered_df['Average Stipend'] <= stipend_range[1])
    ]

st.header("Key Metrics")
col1, col2, col3, col4 = st.columns(4)

total_internships = len(filtered_df)
avg_stipend = filtered_df['Average Stipend'].mean() if 'Average Stipend' in filtered_df.columns else np.nan
avg_duration = filtered_df['Duration (Months)'].mean() if 'Duration (Months)' in filtered_df.columns else np.nan
unique_companies = filtered_df['Company'].nunique() if 'Company' in filtered_df.columns else 0

with col1:
    st.metric("Total Internships (Filtered)", f"{total_internships:,}")
with col2:
    st.metric("Avg. Stipend (INR)", f"₹{avg_stipend:,.2f}" if not pd.isna(avg_stipend) else "N/A")
with col3:
    st.metric("Avg. Duration (Months)", f"{avg_duration:.1f}" if not pd.isna(avg_duration) else "N/A")
with col4:
    st.metric("Unique Companies", f"{unique_companies:,}")

st.markdown("---")

# --- Visualizations ---
st.header("Internship Trends and Distributions")

if filtered_df.empty:
    st.warning("No data available for the selected filters. Please adjust your filter options.")
else:

    col_vis1, col_vis2 = st.columns(2)

    with col_vis1:
        st.subheader("Distribution of Average Stipend")
        if 'Average Stipend' in filtered_df.columns and not filtered_df['Average Stipend'].dropna().empty:
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.histplot(filtered_df['Average Stipend'].dropna(), bins=20, kde=True, ax=ax, color='skyblue')
            ax.set_title('Average Stipend Distribution')
            ax.set_xlabel('Average Stipend (INR)')
            ax.set_ylabel('Number of Internships')
            st.pyplot(fig)
        else:
            st.info("No stipend data available for this visualization with current filters.")

    with col_vis2:
        st.subheader("Top Internship Locations")
        if 'Location' in filtered_df.columns and not filtered_df['Location'].dropna().empty:
            top_locations = filtered_df['Location'].value_counts().head(10)
            if not top_locations.empty:
                fig, ax = plt.subplots(figsize=(10, 6))
                # Assign 'y' variable to 'hue' and set legend=False to address FutureWarning
                sns.barplot(x=top_locations.values, y=top_locations.index, palette='viridis', ax=ax, hue=top_locations.index, legend=False)
                ax.set_title('Top 10 Internship Locations')
                ax.set_xlabel('Number of Internships')
                ax.set_ylabel('Location')
                st.pyplot(fig)
            else:
                st.info("No location data for selected filters.")
        else:
            st.info("Location column not found or is empty for this visualization.")


    col_vis3, col_vis4 = st.columns(2)

    with col_vis3:
        st.subheader("Distribution of Internship Duration")
        if 'Duration (Months)' in filtered_df.columns and not filtered_df['Duration (Months)'].dropna().empty:
            fig, ax = plt.subplots(figsize=(10, 6))
           
            sns.countplot(x=filtered_df['Duration (Months)'].dropna(), palette='coolwarm', ax=ax, hue=filtered_df['Duration (Months)'].dropna(), legend=False)
            ax.set_title('Internship Duration Distribution')
            ax.set_xlabel('Duration (Months)')
            ax.set_ylabel('Number of Internships')
            st.pyplot(fig)
        else:
            st.info("No duration data available for this visualization with current filters.")

    with col_vis4:
        st.subheader("Average Stipend by Duration")
        if 'Duration (Months)' in filtered_df.columns and 'Average Stipend' in filtered_df.columns and not filtered_df[['Duration (Months)', 'Average Stipend']].dropna().empty:
            stipend_by_duration = filtered_df.groupby('Duration (Months)')['Average Stipend'].mean().sort_values(ascending=False)
            if not stipend_by_duration.empty:
                fig, ax = plt.subplots(figsize=(10, 6))
               
                sns.barplot(x=stipend_by_duration.index, y=stipend_by_duration.values, palette='magma', ax=ax, hue=stipend_by_duration.index, legend=False)
                ax.set_title('Average Stipend by Internship Duration')
                ax.set_xlabel('Duration (Months)')
                ax.set_ylabel('Average Stipend (INR)')
                st.pyplot(fig)
            else:
                st.info("No stipend by duration data for selected filters.")
        else:
            st.info("Required columns for this visualization are missing or empty.")

    # Row 3: Mode Distribution
    st.subheader("Distribution of Internship Mode")
    if 'Mode' in filtered_df.columns and not filtered_df['Mode'].dropna().empty:
        mode_counts = filtered_df['Mode'].value_counts()
        if not mode_counts.empty:
            fig, ax = plt.subplots(figsize=(8, 8))
            ax.pie(mode_counts, labels=mode_counts.index, autopct='%1.1f%%', startangle=90, colors=sns.color_palette('pastel'))
            ax.set_title('Distribution of Internship Mode')
            ax.axis('equal')
            st.pyplot(fig)
        else:
            st.info("No mode data for selected filters.")
    else:
        st.info("Mode column not found or is empty for this visualization.")

    st.markdown("---")

    # Display Filtered Data
    st.subheader("Filtered Internship Data")
    display_cols = ['Job Title', 'Company', 'Location', 'Mode', 'Duration (Months)', 'Average Stipend', 'Posted (Days Ago)', 'Job Link']
    existing_display_cols = [col for col in display_cols if col in filtered_df.columns]
    st.dataframe(filtered_df[existing_display_cols])

# --- End of Dashboard ---
